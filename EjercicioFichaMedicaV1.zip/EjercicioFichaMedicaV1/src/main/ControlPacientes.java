//Adminitra procesos CRUD de la estructura de pila
package main;

import clases.*;

public class ControlPacientes {

    public static void main(String[] args) {

        //menu de control
        AdminFicha admin = new AdminFicha();
        int op = 0;
        int nro = 0;
        String fecha;
        String rutp;
        String nombrep;
        String medico;
        String alergia;
        Ficha siguiente;
        do {
            System.out.println("-- Menu de opciones --");
            System.out.println("-----------------------");
            System.out.println("1.-Ingrese Datos");
            System.out.println("2.-Editar Datos");
            System.out.println("3.-Eliminacion Datos");
            System.out.println("4.-Listar Datos");
            System.out.println("5.-Salir");
            System.out.print("Ingrese opcion: ");
            op = Leer.datoInt();

            switch (op) {
                case 1:
                    System.out.println("--Ingrese datos --");
                    System.out.println("-------------------");
                    System.out.print("Ingrese nro: ");
                    nro = Leer.datoInt();
                    System.out.print("Ingrese fecha: ");
                    fecha = Leer.dato();
                    System.out.print("Ingrese rut: ");
                    rutp = Leer.dato();
                    System.out.print("Ingrese nombre: ");
                    nombrep = Leer.dato();
                    System.out.print("Ingrese medico: ");
                    medico = Leer.dato();
                    System.out.print("Ingrese alergia si/no: ");
                    alergia = Leer.dato();
                    admin.agregarFichaPila(nro, fecha, rutp, nombrep, medico, alergia);
                    System.out.println("Nodo agregado a la pila");
                    break;
                case 2:
                    System.out.println("--Edicion datos --");
                    System.out.println("-------------------");
                    System.out.print("Número: ");
                    nro = Leer.datoInt();
                    admin.editarFicha(nro);
                    break;
                case 3:
                    System.out.println("--Eliminar datos --");
                    System.out.println("-------------------");
                    System.out.print("Número: ");
                    admin.eliminarNodoFicha();
                    break;
                case 4:
                    System.out.println("--Listado datos --");
                    System.out.println("-------------------");
                    admin.imprimirPilaFicha();
                    break;
                case 5:
                    System.out.println("Saliendo");
                    break;
                default:
                    System.out.println("Opción inválida!");
            }
        } while (op != 5);
        System.exit(0);
    }
}
