//nodo contiene datos de una ficha
package clases;

public class Ficha {

    //Atributos
    private int nro;
    private String fecha;
    private String rutp;//rut paciente
    private String nombrep;//nombre paciente
    private String medico;
    private String alergia;
    Ficha siguiente;

    //CONSTRUCTOR
    public Ficha() {
    }

    public Ficha(int nro, String fecha, String rutp, String nombrep, String medico, String alergia, Ficha siguiente) {
        this.nro = nro;
        this.fecha = fecha;
        this.rutp = rutp;
        this.nombrep = nombrep;
        this.medico = medico;
        this.alergia = alergia;
        this.siguiente = siguiente;
    }

    //CONSTRUCTOR SIN FICHA
    public Ficha(int nro, String fecha, String rutp, String nombrep, String medico, String alergia) {
        this.nro = nro;
        this.fecha = fecha;
        this.rutp = rutp;
        this.nombrep = nombrep;
        this.medico = medico;
        this.alergia = alergia;
    }

    //GETTERS
    public int getNro() {
        return nro;
    }

    public String getFecha() {
        return fecha;
    }

    public String getRutp() {
        return rutp;
    }

    public String getNombrep() {
        return nombrep;
    }

    public String getMedico() {
        return medico;
    }

    public String getAlergia() {
        return alergia;
    }

    public Ficha getSiguiente() {
        return siguiente;
    }

    //SETTERS
    public void setNro(int nro) {
        this.nro = nro;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public void setRutp(String rutp) {
        this.rutp = rutp;
    }

    public void setNombrep(String nombrep) {
        this.nombrep = nombrep;
    }

    public void setMedico(String medico) {
        this.medico = medico;
    }

    public void setAlergia(String alergia) {
        this.alergia = alergia;
    }

    public void setSiguiente(Ficha siguiente) {
        this.siguiente = siguiente;
    }

    //TOSTRING
    @Override
    public String toString() {
        return "Ficha{" + "nro=" + nro + ", fecha=" + fecha + ", rutp=" + rutp + ", nombrep=" + nombrep + ", medico=" + medico + ", alergia=" + alergia + ", siguiente=" + siguiente + '}';
    }
}
