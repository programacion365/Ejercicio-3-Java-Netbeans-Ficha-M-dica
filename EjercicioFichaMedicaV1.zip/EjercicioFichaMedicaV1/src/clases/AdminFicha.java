//Gestiona procesos de tipo LIFO en la estructura de datos de PILA/STACK
package clases;

import main.Leer;

public class AdminFicha {

    //atributos
    Ficha cab; //cabecera

    //constructor
    public AdminFicha() {
        cab = null;
    }

    //metodo pila vacia
    public boolean pilaVacia() {
        return cab == null;// sin datos retorna true
    }

    //metodo agregar datos a una pila
    public void agregarFichaPila(int nro, String fecha, 
            String rutp, String nombrep, String medico, 
            String alergia) {

        //ptr=puntero
        //puch=ingreso de datos
        Ficha ptr = new Ficha(nro, fecha, rutp, nombrep, medico, alergia);
        ptr.siguiente = cab;
        cab = ptr;
        System.out.println("Nodo agregado a la pila/ficha");
    }

    //metodo eliminar datos a una pila de modo natural
    //proceso de tipo POP
    //ptr = puntero => es un nodo
    //cab = cabecera => es un nodo    
    public void eliminarNodoFicha() {
        Ficha ptr = cab;//cab=nodo ptr=nodo
        cab = cab.siguiente;//cab = debe moverse al registro a la posicion continua
        ptr = null; //sacar de memoria el nodo indicado
        System.out.println("Nodo eliminado!");
    }

    //metodo imprimir ficha
    public void imprimirPilaFicha() {
        if (pilaVacia()) {
            System.out.println("pila sin nodos");
        } else {
            Ficha muestra = cab;
            do {
                System.out.println("Muestra: " + muestra.toString());
                muestra = muestra.siguiente;
            } while (muestra != null);
        }
    }

    //metodo editar ficha
    public void editarFicha(int nro) {

        //.-declarando variables
        int modi = 0;
        int siga = 1;
        String dato = null;

        //.-mensaje de notifiaciones
        if (pilaVacia()) {
            System.out.println("Pila sin nodo");
        } else {
            //read
            Ficha muestra = cab;
            do {
                //comparar
                if (muestra.getNro() == nro) {
                    System.out.println("Muestra encontrada : " + muestra.toString());

                    //ciclo infinito
                    while (siga == 1) {
                        System.out.println("1.-Modificar fecha");
                        System.out.println("2.-Modificar rut");
                        System.out.println("3.-Modificar nombre");
                        System.out.println("4.-Modificar medico");
                        System.out.println("5.-Modificar alergia");
                        System.out.print("Ingrese opción: ");
                        modi = Leer.datoInt();
                        switch (modi) {
                            case 1:
                                System.out.print("Fecha: ");
                                dato = Leer.dato();
                                muestra.setFecha(dato);
                                break;

                            case 2:
                                System.out.print("Rut: ");
                                dato = Leer.dato();
                                muestra.setRutp(dato);
                                break;
                            case 3:
                                System.out.print("Nombre: ");
                                dato = Leer.dato();
                                muestra.setNombrep(dato);
                                break;
                            case 4:
                                System.out.print("Médico: ");
                                dato = Leer.dato();
                                muestra.setMedico(dato);
                                break;
                            case 5:
                                System.out.print("Alergia si/no: ");
                                dato = Leer.dato();
                                muestra.setAlergia(dato);
                                break;
                            default:
                                System.out.println("Opción inválida!");
                        }
                        System.out.println("Nodo modificado: " + muestra.toString());
                        System.out.println("1.-Seguir");
                        System.out.println("2.-Salir");
                        System.out.print("Ingrese opción: ");
                        siga = Leer.datoInt();
                    }
                }
                //ciclar
                muestra = muestra.siguiente;
            } while (muestra != null);
        }
    }
}
